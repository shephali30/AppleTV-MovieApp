//
//  ProfileViewController.swift
//  tvOS_First_Test
//
//  Created by Shephali on 23/03/25.
//

import UIKit

class KeyboardButton: UIButton {

    override func awakeFromNib() {
        backgroundColor = .clear
        setTitleColor(.white, for: .normal)
    }
    
    override func didUpdateFocus(in context: UIFocusUpdateContext, with coordinator: UIFocusAnimationCoordinator) {
        if context.nextFocusedView == self {
            setTitleColor(.orange, for: .normal)
        } else {
            setTitleColor(.white, for: .normal)
        }
    }

}
