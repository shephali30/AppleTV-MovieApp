//
//  DetailViewController.swift
//  tvOS_First_Test
//
//  Created by Shephali on 25/03/25.
//


import UIKit

protocol VideoTableViewCellDelegate: AnyObject {
    func didSelectItem()
}

class VideosTableViewCell: UITableViewCell {

    @IBOutlet weak var videosCollectionViewHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var videosCollectionView: UICollectionView!
    @IBOutlet weak var titleLabel: UILabel!
    
    weak var delegate: VideoTableViewCellDelegate?
    var type: CellType = .trendingMovie
    
    var trendingVideos = ["latest_2","latest_3","latest_1"]
    var carousalVideos = ["carousal_1","carousal_2"]
    var channelList = ["Netflix", "Zee5", "Prime", "Sony liv"]
    var allMovie = ["latest_4","latest_1","latest_2","latest_3","latest_4","latest_1","latest_2","latest_3"]
    
    override func awakeFromNib() {
        super.awakeFromNib()
        videosCollectionView.dataSource = self
        videosCollectionView.delegate = self
        registerNibs()
    }
    
    func registerNibs() {
        videosCollectionView.register(UINib(nibName: "VideosCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "VideosCollectionViewCell")
        videosCollectionView.register(UINib(nibName: "ClassifiedCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "ClassifiedCollectionViewCell")
        videosCollectionView.register(UINib(nibName: "ToolsCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "ToolsCollectionViewCell")
    }
}

extension VideosTableViewCell: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch type {
        case .carousal:
            return carousalVideos.count
        case .trendingMovie:
            return trendingVideos.count
        case .channel:
            return channelList.count
        case .all:
            return allMovie.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        switch type {
        case .carousal:
            if let cell: VideosCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "VideosCollectionViewCell", for: indexPath) as? VideosCollectionViewCell {
                cell.type = type
                cell.posterImageView.image = UIImage(named: carousalVideos[indexPath.row])
                cell.posterImageView.contentMode = .scaleAspectFill
                return cell
            }
            return UICollectionViewCell()
        case .trendingMovie:
            if let cell: VideosCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "VideosCollectionViewCell", for: indexPath) as? VideosCollectionViewCell {
                cell.type = type
                cell.posterImageView.image = UIImage(named: trendingVideos[indexPath.row])
                return cell
            }
            return UICollectionViewCell()
        case .channel:
            if let cell: ClassifiedCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "ClassifiedCollectionViewCell", for: indexPath) as? ClassifiedCollectionViewCell {
                cell.configureView(text: channelList[indexPath.row])
                return cell
            }
            return UICollectionViewCell()
        case .all:
            if let cell: ToolsCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "ToolsCollectionViewCell", for: indexPath) as? ToolsCollectionViewCell {
                cell.posterImageView.image = UIImage(named: allMovie[indexPath.row])
                return cell
            }
            return UICollectionViewCell()
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        switch type {
        case .carousal:
            return CGSize(width: collectionView.frame.size.width - 180, height: collectionView.frame.size.height)
        case .trendingMovie, .all:
            return CGSize(width: (16/9) * collectionView.frame.size.height, height: collectionView.frame.size.height)
        case .channel:
            return CGSize(width: 360, height: 360)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        delegate?.didSelectItem()
    }
}
